"Groupondeals Locator" - Udacity Neighborhood Map Project
--------

Use this app to find deals anywhere, where-ever you live or wherever you go. 


Features
-------

* Autocomplete deal location search
* search you city in the seacrh bar to display local deals
* Clicking on the markers displays further deal and location information
* Search produces top thirty results near your requested location
* Filter deals by restaurant name 
* Integrated list view links to corresponding map marker on click
* Mobile friendly view hides list and search bar until you need it
* CLick recentering object to Re-center your map if you stray too far
* Search for tag ie name of restaurant or food type


Resources 
-----

* Google Maps API Documentation
* Groupon API Documentation

